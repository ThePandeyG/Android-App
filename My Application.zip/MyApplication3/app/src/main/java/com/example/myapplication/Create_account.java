package com.example.a9soft.miniproject;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
/**
 * Created by 9Soft on 19/04/2021.
 */
public class create_account extends Activity {
    EditText username,email_id,password;
    TextView create_account,reset;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_account);
        username=(EditText) findViewById(R.id.username);
        email_id=(EditText)findViewById(R.id.email_id);
        password=(EditText)findViewById(R.id.password);
        create_account=(TextView)findViewById(R.id.create_account);
        create_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues val=new ContentValues();
                val.put("username",username.getText().toString());
                val.put("email_id",email_id.getText().toString());
                val.put("password",password.getText().toString());
                try{
                    DBAdapter db=new DBAdapter(getApplicationContext());
                    db.open();
                    long i=db.insertData(val,"user_info");
                    if(i!=-1){
                        Toast.makeText(create_account.this, "Account Created
                                Successfully ", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(create_account.this, "Some Error Found",
                                Toast.LENGTH_SHORT).show();
                    }
                    db.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
                Intent i=new Intent(getApplicationContext(),login.class);
                startActivity(i);
            }
        });
        reset=(TextView)findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username.setText("");
                password.setText("");
                email_id.setText("");
            }
        });
    }
}