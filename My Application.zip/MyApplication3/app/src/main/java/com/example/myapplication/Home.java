package com.example.a9soft.miniproject;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;
/**
 * Created by 9Soft on 19/04/2021.
 */
public class home extends Activity {
    TextView post,preview;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        post=(TextView)findViewById(R.id.post);
        preview=(TextView)findViewById(R.id.preview);
        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),post_advrt.class);
                startActivity(i);
            }
        });
        preview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),preview_advrt.class);
                startActivity(i);
            }
        });
    }
}

