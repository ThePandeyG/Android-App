package com.example.a9soft.miniproject;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
/**
 * Created by 9Soft on 19/04/2021.
 */
public class login extends Activity {
    EditText username,password;
    TextView login,create_account;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        username=(EditText) findViewById(R.id.username);
        password=(EditText)findViewById(R.id.password);
        create_account=(TextView)findViewById(R.id.create_account);
        create_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),create_account.class);
                startActivity(i);
            }
        });
        login=(TextView)findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    DBAdapter db=new DBAdapter(getApplicationContext());
                    db.open();
                    Cursor
                            c=db.getValidAccount(username.getText().toString(),password.getText().toString());
                    if(c.moveToFirst()){
                        Toast.makeText(login.this, "Successfully",
                                Toast.LENGTH_SHORT).show();
                        Intent i=new Intent(getApplicationContext(),home.class);
                        startActivity(i);
                    }else{
                        Toast.makeText(login.this, "Please Enter Correct Information",
                                Toast.LENGTH_SHORT).show();
                    }
                    db.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
    }
}