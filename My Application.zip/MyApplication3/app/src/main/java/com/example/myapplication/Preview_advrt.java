package com.example.a9soft.miniproject;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
/**
 * Created by 9Soft on 19/04/2021.
 */
public class preview_advrt extends Activity {
    TextView product_name,company_name,category,mrp,back;
    ImageView img;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.preview_adv);
        product_name=(TextView)findViewById(R.id.product_name);
        company_name=(TextView)findViewById(R.id.company_name);
        category=(TextView)findViewById(R.id.category);
        mrp=(TextView)findViewById(R.id.mrp);
        back=(TextView)findViewById(R.id.back);
        img=(ImageView)findViewById(R.id.img);
        getProductInfo();
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(),home.class);
                startActivity(i);
            }
        });
    }
    private void getProductInfo() {
        try{
            DBAdapter db=new DBAdapter(getApplicationContext());
            db.open();
            Cursor c=db.getProductInfo();
            if(c.moveToFirst()){
                do{

                    product_name.setText(c.getString(c.getColumnIndex("product_name")));

                    company_name.setText(c.getString(c.getColumnIndex("company_name")));
                    category.setText(c.getString(c.getColumnIndex("category")));
                    mrp.setText(c.getString(c.getColumnIndex("mrp")));
                    byte[] byteArray=c.getBlob(c.getColumnIndex("img"));
                    Bitmap compressedBitmap =
                            BitmapFactory.decodeByteArray(byteArray,0,byteArray.length);

                    img.setImageBitmap(compressedBitmap);//c.getBlob(c.getColumnIndex("img")));
                }while (c.moveToNext());
            }
            db.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}