package com.example.a9soft.miniproject;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
/**
 * Created by 9Soft on 16/04/2021.
 */
public class DBAdapter {
    private static final String DB_Name="shop.db";
    private static final String tbl_name1="user_info";
    private static final String tbl_name2="user_status";
    private static final String tbl_name3="product_info";
    private static final int version=2;
    private static final String user_info_tbl="create table user_info(_id integer
    primary key autoincrement,username text not null,email_id text not null,password text
    not null);";
    private static final String user_status_tbl="create table user_status(_id integer
    primary key autoincrement,username text not null,status text not null)";
    private static final String product_info_tbl="create table product_info(_id
    integer primary key autoincrement,product_name text not null,company_name text not
null,mrp text not null,category text not null,img blob not null)";
    final Context con;
    DatabaseHelper helper;
    SQLiteDatabase db;
    public DBAdapter(Context cont) {
        this.con = cont;
        helper=new DatabaseHelper(cont,DB_Name,null,version);
    }
    private class DatabaseHelper extends SQLiteOpenHelper {
        public DatabaseHelper(Context context, String name,
                              SQLiteDatabase.CursorFactory factory, int version) {
            super(context,name,factory,2);
        }
        @Override
        public void onCreate(SQLiteDatabase db) {
            // db=sqLiteDatabase;
            try{
                Log.e("callM","method call");
                // db.execSQL(null);
                db.execSQL(user_info_tbl);
                db.execSQL(user_status_tbl);
                db.execSQL(product_info_tbl);
            }catch (Exception e){
                e.printStackTrace();
                Log.e("error1",e.getLocalizedMessage());
            }
        }
        @Override
        public void onUpgrade(SQLiteDatabase database, int i, int i1) {
            // db=sqLiteDatabase;
            database.execSQL("DROP TABLE IF EXISTS user_info");
            database.execSQL("DROP TABLE IF EXISTS user_status");
            database.execSQL("DROP TABLE IF EXISTS product_info_tbl");
            onCreate(database);
        }
    }
    public DBAdapter open() throws SQLException {
        db=helper.getWritableDatabase();
        return this;
    }
    public void close(){
        helper.close();
    }
    public long insertData(ContentValues val,String tbl_name){
        return db.insert(tbl_name,null,val);
    }
    public Cursor getUserStatus(String username){
        return db.rawQuery("select * from user_status where username like
        '"+username+"'",null);
    }
    public Cursor getValidAccount(String username,String password){
        return db.rawQuery("select * from user_info where username like '"+username+"'
                AND password like '"+password+"'",null);
    }
    public Cursor getProductInfo(){
        return db.rawQuery("select * from product_info",null);
    }
    public boolean deleteProductInfo(String product_id){
        return db.delete("product_info","product_id='"+product_id+"'",null) > 0;
    }
}