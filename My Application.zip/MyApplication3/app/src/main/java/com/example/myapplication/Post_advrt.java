package com.example.a9soft.miniproject;
import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
/**
 * Created by 9Soft on 19/04/2021.
 */
public class post_advrt extends Activity {
    EditText product_name,company_name,category,mrp;
    TextView post_ads,reset,add_product;
    ImageView img;
    String real_path;
    protected static final int RESULT_LOAD_IMAGE = 1;
    Uri currImageUri;
    Bitmap bitmapOrg;
    byte[] byteArray=null;
    boolean flag=false;
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_advrt);
        product_name=(EditText)findViewById(R.id.product_name);
        company_name=(EditText)findViewById(R.id.company_name);
        category=(EditText)findViewById(R.id.category);
        mrp=(EditText)findViewById(R.id.mrp);
        byteArray=null;
        int permission = ActivityCompat.checkSelfPermission(post_advrt.this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(post_advrt.this,PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE);
        }
        add_product=(TextView)findViewById(R.id.add);
        add_product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gallaryIntent=new
                        Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_UR
                        I);
                startActivityForResult(gallaryIntent, RESULT_LOAD_IMAGE);
            }
        });
        post_ads=(TextView)findViewById(R.id.post);
        post_ads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues val=new ContentValues();
                val.put("product_name",product_name.getText().toString());
                val.put("company_name",company_name.getText().toString());
                val.put("category",category.getText().toString());
                val.put("mrp",mrp.getText().toString());
                val.put("img",byteArray);
                try{
                    DBAdapter db=new DBAdapter(getApplicationContext());
                    db.open();
                    long i=db.insertData(val,"product_info");
                    if(i!=-1){
                        Toast.makeText(post_advrt.this, "Product Added
                                Successfully", Toast.LENGTH_SHORT).show();
                                Intent itent=new
                                        Intent(getApplicationContext(),home.class);
                        startActivity(itent);
                    }else {
                        Toast.makeText(post_advrt.this, "Some Error Found",
                                Toast.LENGTH_SHORT).show();
                    }
                    db.close();
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        reset=(TextView)findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                product_name.setText("");
                company_name.setText("");
                category.setText("");
                mrp.setText("");
                img.setImageBitmap(null);
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(requestCode, resultCode, data);
        if(flag){
            img.setImageBitmap((Bitmap)data.getExtras().get("data"));
            flag=false;
        }else{
            if(requestCode==RESULT_LOAD_IMAGE && resultCode== RESULT_OK &&
                    null!=data)
            {
                currImageUri = data.getData();
                // System.out.println("CurrentImage Path Is---
>>"+getRealPathFromUri(currImageUri));
                real_path=getRealPathFromUri(currImageUri);
                bitmapOrg= BitmapFactory.decodeFile(real_path);
                img.setImageBitmap(null);
                img.setImageBitmap(bitmapOrg);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmapOrg.compress(Bitmap.CompressFormat.JPEG,80,stream);
                byteArray = stream.toByteArray();
            }
        }
    }
    private String getRealPathFromUri(Uri currImageUri2) {
        // TODO Auto-generated method stub
        String[] proj = {MediaStore.MediaColumns.DATA};
        Cursor cursor = getContentResolver().query(currImageUri2, proj, null, null,
                null);
        cursor.moveToFirst();
        int columnIndex = cursor.getColumnIndex(proj[0]);
        String picturePath = cursor.getString(columnIndex);
        cursor.close();
        return picturePath;
    }